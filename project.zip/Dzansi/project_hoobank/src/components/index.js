import Navbar from "./Navbar";
import Billing from "./Family";
import CardDeal from "./Events";
import Business from "./About us";
import Testimonies from "./Testimonies";
import CTA from "./CTA";
import Stats from "./Stats";
import Footer from "./Footer";
import Testimonials from "./Testimonials";
import Hero from "./Home";

export {
  Navbar,
  Billing,
  CardDeal,
  Business,
  Testimonies,
  CTA,
  Stats,
  Footer,
  Testimonials,
  Hero,
};
